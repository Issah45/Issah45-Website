document.body.style.overflow = "hidden";

function rect(x, y, width, height, bg) {
	return {
		x: x, y: y,
		width: width,
		height: height,
		backColor: bg
	};
};

function setup(o1, o2) {
	o1.style.position = "absolute";
	o1.style.width = o2.width.toString() + "px";
	o1.style.height = o2.height.toString() + "px";
	o1.style.left = o2.x.toString() + "px";
	o1.style.top = o2.y.toString() + "px";
};

function setupBg(o1, o2) {
	o1.style.background = o2.backColor;
};

function tick(seconds, func) {
	return setInterval(func, seconds);
};

function fps(value=60) {
	return 1000 / value;
};

function unTick(o1) {
	clearInterval(o1);
};